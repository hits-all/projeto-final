
function getCadastros() {
    const cadastros = localStorage.getItem('cadastros');
    return cadastros ? JSON.parse(cadastros) : [];
}


function saveCadastros(cadastros) {
    localStorage.setItem('cadastros', JSON.stringify(cadastros));
}


function adicionarCadastro(nome, email, telefone) {
    const cadastros = getCadastros();
    cadastros.push({ nome, email, telefone });
    saveCadastros(cadastros);
    renderTabela();
}


function renderTabela() {
    const tabela = document.getElementById('tabelaCadastros').getElementsByTagName('tbody')[0];
    tabela.innerHTML = ''; 
    const cadastros = getCadastros();
    cadastros.forEach(cadastro => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${cadastro.nome}</td>
            <td>${cadastro.email}</td>
            <td>${cadastro.telefone}</td>
        `;
        tabela.appendChild(tr);
    });
}


document.getElementById('formCadastro').addEventListener('submit', function(event) {
    event.preventDefault();
    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email').value;
    const telefone = document.getElementById('telefone').value;
    
   
    adicionarCadastro(nome, email, telefone);

 
    document.getElementById('nome').value = '';
    document.getElementById('email').value = '';
    document.getElementById('telefone').value = '';
});


renderTabela();
